package command.Enum;

import Exceptions.TradingTypeError;

public enum TradingTypes {

    BUY, SELL;



}
