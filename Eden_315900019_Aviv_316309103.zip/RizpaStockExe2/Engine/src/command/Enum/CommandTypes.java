package command.Enum;

import Exceptions.CommandTypeError;

public enum CommandTypes {
    MKT,LMT;


}
