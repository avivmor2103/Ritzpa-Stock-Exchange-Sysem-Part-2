package Exceptions;

public class CommandTypeError extends Exception {

    public CommandTypeError(String message){
        super(message);
    }
}
