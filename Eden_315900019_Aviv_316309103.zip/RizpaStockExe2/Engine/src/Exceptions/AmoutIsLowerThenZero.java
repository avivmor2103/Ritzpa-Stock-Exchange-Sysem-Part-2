package Exceptions;

public class AmoutIsLowerThenZero extends Exception{
    public AmoutIsLowerThenZero(String message) {
        super(message);
    }
}
