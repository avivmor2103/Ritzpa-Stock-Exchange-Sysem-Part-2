package Exceptions;

public class SymbolIsAlreadyExists extends Exception{

    public SymbolIsAlreadyExists(String massage) {
        super(massage);
    }


}
