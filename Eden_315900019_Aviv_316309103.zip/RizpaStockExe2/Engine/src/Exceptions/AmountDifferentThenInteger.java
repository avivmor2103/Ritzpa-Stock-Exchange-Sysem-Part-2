package Exceptions;

public class AmountDifferentThenInteger extends Exception {
    public AmountDifferentThenInteger(String message)  {
        super(message);
    }
}
