package Exceptions;

public class UserNameIsAlreadyExists extends Exception {

        public UserNameIsAlreadyExists(String message)
        {
            super(message);
        }
}
