package Exceptions;

public class SymbolNotExists extends Exception{
    public SymbolNotExists(String message)
    {
        super(message);
    }
}
