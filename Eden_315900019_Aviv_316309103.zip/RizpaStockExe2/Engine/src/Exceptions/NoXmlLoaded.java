package Exceptions;

public class NoXmlLoaded extends Exception {

    public NoXmlLoaded(String message) {
        super(message);
    }
}