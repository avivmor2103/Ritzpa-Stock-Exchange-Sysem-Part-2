package Exceptions;

public class TradingTypeError extends Exception{

    public TradingTypeError(String message){
        super(message);}

}
