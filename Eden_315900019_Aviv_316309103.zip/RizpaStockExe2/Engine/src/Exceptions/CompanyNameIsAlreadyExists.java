package Exceptions;

public class CompanyNameIsAlreadyExists extends Exception{

    public CompanyNameIsAlreadyExists(String message)
    {
     super(message);
    }
}
